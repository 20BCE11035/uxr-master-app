package com.example.scenario_code

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
